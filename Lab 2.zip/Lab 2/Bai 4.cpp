#include <stdio.h>
int main(){
	float Toan, Ly, Hoa;
	printf("Hay nhap diem mon Toan: "); scanf("%f", &Toan);
	printf("Hay nhap diem mon Ly: "); scanf("%f", &Ly);
	printf("Hay nhap diem mon Hoa: "); scanf("%f", &Hoa);
	printf("Diem trung binh Toan Ly Hoa: %.2f", (Toan * 3 + Ly * 2 + Hoa) / 6);
	}
