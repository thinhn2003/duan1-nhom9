#include <stdio.h>
int main(){
	int a, b;
	printf("Hay nhap a: ");
	scanf("%d", &a);
	printf("Hay nhap b: ");
	scanf("%d", &b);
	printf("Tong: %d", a + b);
	printf("\nHieu: %d", a - b);
}
