#include <stdio.h>
int main()
{
	int chieudai, chieurong;
	printf("Vui long nhap chieu dai: ");
	scanf("%d", &chieudai);
	printf("Vui long nhap chieu rong: ");
	scanf("%d", &chieurong);
	printf("Chu vi HCN: %d", (chieudai + chieurong) / 2);
	printf("\nDien tich HCN: %d", chieudai * chieurong);
}
