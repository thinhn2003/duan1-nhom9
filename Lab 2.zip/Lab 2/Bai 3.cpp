#include <stdio.h>
int main()
{
	int r;
	float PI = 3.14;
	printf("Moi ban nhap ban kinh: "); scanf("%d", &r);
	printf("Chu vi hinh tron: %d", (r * 2) * PI);
	printf("\nDien tich hinh tron: %d", r * r * PI);
}
